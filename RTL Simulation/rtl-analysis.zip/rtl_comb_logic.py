"""Summarize supported combinational RTL as output value decisions."""

from dataclasses import dataclass, field
from itertools import islice

from pyslang import SVInt, ast

from rtl_case_regions import CASE_NAMES, case_label
from rtl_process_view import expression_label, statements, unconverted
from rtl_schematic import Drawing, level_control
from rtl_structure import VALUE_EXPRESSIONS, integer_literal, signal_refs


@dataclass(frozen=True)
class Value:
    text: str
    inputs: frozenset = frozenset()
    controls: frozenset = frozenset()
    fields: tuple = ()
    retained: bool = False
    source: dict | None = field(default=None, compare=False)
    bindings: tuple = ()
    expression: ast.Expression | None = field(default=None, compare=False, repr=False)


@dataclass(frozen=True)
class Match:
    label: str
    values: tuple
    keys: tuple
    region: str | None = field(default=None, compare=False)


@dataclass(frozen=True)
class Decision:
    kind: str
    selector: Value
    arms: tuple
    fallback: "Value | Decision"
    inputs: frozenset
    controls: frozenset
    priority: bool = False
    region: str | None = field(default=None, compare=False)
    default_region: str | None = field(default=None, compare=False)
    arm_writes: tuple = field(default=(), compare=False)


class UnsupportedProcess(Exception):
    pass


def input_dependencies(expr, state):
    data, controls = set(), set()
    for net in signal_refs(expr):
        previous = state.get(net)
        if previous is None:
            data.add(net)
        else:
            data.update(previous.inputs)
            controls.update(previous.controls)
    return frozenset(data), frozenset(controls)


def bit_fields(expr, text):
    bare = unconverted(expr)
    if not isinstance(bare, (ast.ConcatenationExpression, ast.ReplicationExpression)) or not bare.type.isIntegral:
        return ()
    width = bare.type.bitWidth
    operands = bare.operands if isinstance(bare, ast.ConcatenationExpression) else [bare]
    result = []
    for operand in operands:
        if operand.type.bitWidth:
            low = width - operand.type.bitWidth
            result.append((f"[{width - 1}:{low}]" if width - low > 1 else f"[{low}]",
                           expression_label(operand, text)))
            width = low
    return tuple(result)


def value(expr, state, locate, text, reuse_decision=False):
    bare = unconverted(expr)
    source = locate(expr.sourceRange.start) if expr.sourceRange.start else None
    if isinstance(bare, VALUE_EXPRESSIONS):
        previous = state.get(bare.symbol.hierarchicalPath)
        if previous is not None and bare.type.bitWidth == expr.type.bitWidth and bare.type.isSigned == expr.type.isSigned:
            if isinstance(previous, Value):
                return Value(previous.text, previous.inputs, previous.controls, previous.fields,
                             previous.retained, source, previous.bindings, previous.expression)
            if reuse_decision:
                return previous

    inputs, controls = input_dependencies(expr, state)
    selectors = set(controls)

    def visit(node):
        if isinstance(node, ast.CallExpression) and getattr(node, "subroutineName", "") not in {"$signed", "$unsigned"}:
            raise UnsupportedProcess()
        if isinstance(node, ast.AssignmentExpression):
            raise UnsupportedProcess()
        if isinstance(node, ast.ConditionalExpression):
            for condition in node.conditions:
                if condition.pattern is not None:
                    raise UnsupportedProcess()
                left, right = input_dependencies(condition.expr, state)
                selectors.update(left | right)

    bare.visit(visit)
    bindings = tuple((net, state[net]) for net in signal_refs(expr) if net in state)
    return Value(expression_label(expr, text), inputs, frozenset(selectors), bit_fields(expr, text),
                 source=source, bindings=bindings, expression=expr)


def case_key(expr, selector_width):
    if expr.type.bitWidth != selector_width:
        return None
    value = integer_literal(expr)
    bare = unconverted(expr)
    if (value is None and bare.type.bitWidth == selector_width and bare.type.isSigned == expr.type.isSigned and
            isinstance(bare, VALUE_EXPRESSIONS) and isinstance(bare.symbol, ast.ParameterSymbol)):
        item = bare.symbol.value.value
        if isinstance(item, SVInt) and not item.hasUnknown:
            value = int(item)
    bits = expr.type.bitWidth
    return (bits, value & ((1 << bits) - 1)) if value is not None and bits else None


class RuleDrawing(Drawing):
    def __init__(self, text, cases=None, destination=None):
        super().__init__(text, self.resolve, cases, destination)
        self.locals = {}
        self.cached = {}

    def resolve(self, expr):
        if isinstance(expr, VALUE_EXPRESSIONS):
            outcome = self.locals.get(expr.symbol.hierarchicalPath)
            if outcome is not None:
                return self.outcome(outcome)
        if isinstance(expr, (ast.RangeSelectExpression, ast.ElementSelectExpression)):
            base = unconverted(expr.value)
            if isinstance(base, VALUE_EXPRESSIONS) and base.symbol.hierarchicalPath in self.locals:
                inputs = [("A", self.outcome(self.locals[base.symbol.hierarchicalPath]))]
                # Constant selections are fully described by their range label.
                indices = ([expr.left, expr.right] if isinstance(expr, ast.RangeSelectExpression)
                           else [expr.selector])
                for index in indices:
                    if signal_refs(index):
                        inputs.append((str(len(inputs)), self.expression(index)))
                label = expression_label(expr, self.text)
                if len(inputs) == 1:
                    return self.add("operator", label, inputs, symbol="[:]", bits=expr.type.bitWidth)
                return self.add("expression", label, [(str(i + 1), node) for i, (_, node) in enumerate(inputs)])
        if isinstance(expr, ast.CallExpression) and expr.subroutineName in {"$signed", "$unsigned"}:
            return self.add("operator", expr.subroutineName, [("A", self.expression(expr.arguments[0]))],
                            symbol="cast", bits=expr.type.bitWidth)
        return None

    def outcome(self, value):
        key = id(value)
        if key in self.cached:
            return self.cached[key]
        if isinstance(value, Value):
            if value.expression is None:
                result = self.terminal(value.text, sorted(value.inputs))
            else:
                previous = self.locals
                self.locals = dict(value.bindings)
                try:
                    result = self.expression(value.expression)
                finally:
                    self.locals = previous
        else:
            result = self.outcome(value.fallback)
            if value.default_region:
                result = self.arm_value(value.default_region, result)
            for index in reversed(range(len(value.arms))):
                match, outcome = value.arms[index]
                if (self.cases and match is not None and not value.priority and
                        not value.arm_writes[index] and outcome == value.fallback):
                    continue
                condition = self.arm_match(value, index)
                branch = f"if {value.selector.text}" if match is None else f"{value.kind} {match.label}"
                alternate = self.outcome(outcome)
                if match is not None:
                    alternate = self.arm_value(match.region, alternate)
                zero_bits = self.nodes[result].get("bits")
                one_bits = self.nodes[alternate].get("bits")
                fallback = ("Else" if match is None else
                            "No match" if index == len(value.arms) - 1 else "Next case arm")
                with self.in_region(value.region):
                    result = self.mux(result, alternate, condition, branch=branch, fallback=fallback,
                                      bits=one_bits if zero_bits == one_bits else None)
        self.cached[key] = result
        return result

    def latched_value(self, value, net, saved):
        """Return the data and write enable, discarding data on hold paths."""
        key = id(value)
        if key in saved:
            return saved[key]
        if isinstance(value, Value):
            result = (None, None) if value.retained and net in value.inputs else (self.outcome(value), None)
        else:
            data, enable = self.latched_value(value.fallback, net, saved)
            if data is not None:
                data = self.arm_value(value.default_region, data)
            for index in reversed(range(len(value.arms))):
                branch, write = self.latched_value(value.arms[index][1], net, saved)
                if branch is None and data is None:
                    continue
                select = self.arm_match(value, index)
                match = value.arms[index][0]
                if branch is not None and match is not None:
                    branch = self.arm_value(match.region, branch)
                with self.in_region(value.region):
                    data, enable = self.merge_latch(data, enable, branch, write, select)
            result = (data, enable)
        saved[key] = result
        return result

    def merge_latch(self, data, enable, branch, write, select):
        if data is None:
            return branch, self.combine([select, write] if write is not None else [select], "AND")
        if branch is None:
            reject = self.add("gate", "NOT", [("A", select)], bits=1)
            return data, self.combine([reject, enable] if enable is not None else [reject], "AND")
        data = self.mux(data, branch, select)
        if enable is not None or write is not None:
            yes = self.terminal("1'b1", bits=1)
            enable = self.mux(yes if enable is None else enable, yes if write is None else write, select,
                              bits=1)
        return data, enable

    def latch(self, value, symbol):
        net = symbol.hierarchicalPath
        if (isinstance(value, Decision) and value.kind == "if" and not value.selector.bindings
                and isinstance(value.fallback, Value) and value.fallback.retained and net in value.fallback.inputs):
            level = level_control(value.selector.expression)
            data, enable = self.latched_value(value.arms[0][1], net, {})
            if level is not None and data is not None and enable is None:
                signal, low = level
                return self.add("latch", symbol.name, [("D", data), ("EN", self.expression(signal))],
                                bits=symbol.type.bitWidth, enableLow=low)
        data, enable = self.latched_value(value, net, {})
        if data is not None and enable is not None:
            return self.add("latch", symbol.name, [("D", data), ("EN", enable)], bits=symbol.type.bitWidth)
        return self.outcome(value)

    def match_operand(self, match):
        bare = unconverted(match.expression)
        if (isinstance(bare, (ast.ConcatenationExpression, ast.ReplicationExpression))
                and not match.inputs and not match.controls and not match.bindings):
            return self.terminal(self.text(bare) or match.text, bits=bare.type.bitWidth)
        label = case_label(match.expression, match.text)
        if label != match.text:
            return self.terminal(label)
        return self.outcome(match)

    def arm_match(self, decision, index):
        selector = self.outcome(decision.selector)
        if decision.kind == "if":
            with self.in_region(decision.region):
                return self.add("operator", "If condition is true", [("A", selector)], symbol="true", bits=1)
        compare = {"case": ("Case equality", "==="), "casez": ("Casez match", "?="),
                   "casex": ("Casex match", "?=")}[decision.kind]
        match = decision.arms[index][0]
        with self.in_region(match.region):
            tests = [self.add("operator", compare[0], [("A", selector), ("B", self.match_operand(value))],
                              symbol=compare[1], bits=1) for value in match.values]
            return self.combine(tests, "OR")

    def selected(self, decision, index):
        count = len(decision.arms)
        if decision.kind == "if" and index == 0:
            return self.arm_match(decision, 0)
        terms = []
        if index < count:
            terms.append(self.arm_match(decision, index))
        if index == count or (decision.priority and index > 0):
            earlier = self.combine([self.arm_match(decision, prev) for prev in range(index)], "OR")
            terms.append(self.add("gate", "NOT", [("A", earlier)], bits=1))
        return self.combine(terms, "AND")


def data_circuit(value, symbol, text, source, latch=False, cases=None):
    drawing = RuleDrawing(text, cases, symbol.name if cases else None)
    driver = drawing.latch(value, symbol) if latch else drawing.outcome(value)
    # Keep a distinct endpoint for an output whose previous value is retained.
    width = symbol.type.bitWidth
    bounds = str(symbol.type.fixedRange) if width > 1 else ""
    sink = drawing.output(symbol.name, driver, ["$result"], bits=width, range=bounds)
    return drawing.finish(symbol.name, source, sink)


def rule_circuits(leaf, path, symbol, text):
    circuits = {"data": data_circuit(leaf, symbol, text, leaf.source)}
    if path:
        control = RuleDrawing(text)
        enable = control.combine([control.selected(decision, index) for decision, index in path], "AND")
        sink = control.output("Enable", enable, ["$selected"], bits=1)
        circuits["selection"] = control.finish("Select this rule", leaf.source, sink)
    return circuits


def rules(node, symbol, text, when=(), path=()):
    if isinstance(node, Value):
        bindings = [[name.rsplit(".", 1)[-1], value.text if isinstance(value, Value) else "selected earlier"]
                    for name, value in node.bindings]
        return iter(({"when": list(when), "value": node.text, "fields": node.fields, "locals": bindings,
                      "source": node.source, "retained": node.retained,
                      "circuits": rule_circuits(node, path, symbol, text)},))

    def choices():
        if node.kind == "if":
            yield from rules(node.arms[0][1], symbol, text, (*when, node.selector.text + " is true"),
                             (*path, (node, 0)))
            yield from rules(node.fallback, symbol, text, (*when, "otherwise for " + node.selector.text),
                             (*path, (node, 1)))
        else:
            for index, (match, branch) in enumerate(node.arms):
                yield from rules(branch, symbol, text,
                                 (*when, f"{node.kind} {node.selector.text} matches {match.label}"),
                                 (*path, (node, index)))
            yield from rules(node.fallback, symbol, text, (*when, f"no {node.kind} match for {node.selector.text}"),
                             (*path, (node, len(node.arms))))

    return choices()


def collect_roles(node, seen, conditions, dispatches, data_nets):
    if id(node) in seen:
        return
    seen.add(id(node))
    if isinstance(node, Value):
        data_nets.update(node.inputs - node.controls)
        return
    destination = conditions if node.kind == "if" else dispatches
    destination.setdefault(node.selector.text, None)
    for _, branch in node.arms:
        collect_roles(branch, seen, conditions, dispatches, data_nets)
    collect_roles(node.fallback, seen, conditions, dispatches, data_nets)


def summarize_combinational(body, locate, text, latch_outputs, cases=None):
    symbols = {}
    initial = {}

    def stored(net, state):
        if net not in state:
            initial.setdefault(net, Value("Retain " + symbols[net].name, frozenset({net}), retained=True))
        return state[net] if net in state else initial[net]

    def merge(state, kind, control, arms, otherwise, region=None, default_region=None):
        keys = [key for match, _ in arms if match for key in match.keys]
        priority = kind != "case" or None in keys or len(keys) != len(set(keys))
        merged = state.copy()
        written = dict.fromkeys(net for _, branch in arms for net in branch)
        written.update(dict.fromkeys(otherwise))
        for net in written:
            fallback = stored(net, otherwise)
            choices = tuple((label, stored(net, branch)) for label, branch in arms)
            if all(outcome == fallback for _, outcome in choices):
                merged[net] = fallback
                continue
            results = [*(outcome for _, outcome in choices), fallback]
            controls = control.inputs | control.controls
            for match, _ in arms:
                if match:
                    controls = controls.union(*(item.inputs | item.controls for item in match.values))
            merged[net] = Decision(kind, control, choices, fallback,
                                   controls.union(*(result.inputs for result in results)),
                                   controls.union(*(result.controls for result in results)), priority, region,
                                   default_region if otherwise.get(net) is not state.get(net) else None,
                                   tuple(branch.get(net) is not state.get(net) for _, branch in arms))
        return merged

    def evaluate(stmt, state):
        state = state.copy()
        for part in statements(stmt):
            if isinstance(part, ast.TimedStatement):
                # The outer sensitivity event has already been identified as combinational.
                raise UnsupportedProcess()
            if isinstance(part, ast.ConditionalStatement):
                if len(part.conditions) != 1 or part.conditions[0].pattern is not None:
                    raise UnsupportedProcess()
                predicate = value(part.conditions[0].expr, state, locate, text)
                state = merge(state, "if", predicate,
                              [(None, evaluate(part.ifTrue, state))], evaluate(part.ifFalse, state),
                              cases.owner(part) if cases else None)
            elif isinstance(part, ast.CaseStatement):
                kind = CASE_NAMES.get(part.condition.name)
                if kind not in {"case", "casez", "casex"}:
                    raise UnsupportedProcess()
                select = value(part.expr, state, locate, text)
                arms = []
                for index, arm in enumerate(part.items):
                    matches = [value(expr, state, locate, text) for expr in arm.expressions]
                    labels = ", ".join(case_label(expr, match.text)
                                       for expr, match in zip(arm.expressions, matches))
                    keys = tuple(case_key(expr, part.expr.type.bitWidth) for expr in arm.expressions)
                    match = Match(labels, tuple(matches), keys, cases.arm(part, index) if cases else None)
                    arms.append((match, evaluate(arm.stmt, state)))
                case_region = cases.case(part) if cases else None
                default_region = cases.arm(part, len(part.items)) if cases and part.defaultCase is not None else None
                state = merge(state, kind, select, arms, evaluate(part.defaultCase, state), case_region, default_region)
            elif isinstance(part, ast.ExpressionStatement) and isinstance(part.expr, ast.AssignmentExpression):
                item = part.expr
                if (not isinstance(item.left, VALUE_EXPRESSIONS) or not item.left.type.isIntegral or
                        item.isCompound or item.isNonBlocking or item.timingControl is not None):
                    raise UnsupportedProcess()
                symbol = item.left.symbol
                net = symbol.hierarchicalPath
                symbols[net] = symbol
                state[net] = value(item.right, state, locate, text, reuse_decision=True)
            else:
                raise UnsupportedProcess()
        return state

    try:
        result = evaluate(body.stmt if isinstance(body, ast.TimedStatement) else body, {})
    except UnsupportedProcess:
        return None
    if not result:
        return None

    conditions, dispatches, seen = {}, {}, set()
    outputs, dependencies, control_nets, data_nets = [], set(), set(), set()
    for net, outcome in result.items():
        symbol = symbols[net]
        rows = list(islice(rules(outcome, symbol, text), 257))
        if len(rows) > 256:
            return None
        collect_roles(outcome, seen, conditions, dispatches, data_nets)
        dependencies.update(outcome.inputs)
        control_nets.update(outcome.controls)
        outputs.append({"net": net, "name": symbol.name, "bits": symbol.type.bitWidth,
                        "range": str(symbol.type.fixedRange) if symbol.type.bitWidth > 1 else "",
                        "inputs": sorted(outcome.inputs), "controls": sorted(outcome.controls),
                        "circuit": data_circuit(outcome, symbol, text, rows[0]["source"],
                                                latch=latch_outputs.get(net) == symbol.type.bitWidth, cases=cases),
                        "rules": rows})
    return {"inputs": sorted(dependencies), "controls": sorted(control_nets), "dataInputs": sorted(data_nets),
            "conditions": list(conditions), "selectors": list(dispatches), "outputs": outputs}
